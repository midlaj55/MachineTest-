//
//  SearchBarView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI

struct SearchBarView: View {
    @State private var text: String = ""

    var body: some View {
        HStack {
            Button(action: {}, label: {
                Image("shoping_icon")
            })
            textfieldView
            Button(action: {}, label: {
                Image("notification_icon")
                    .frame(width: 11, height: 11)
            })
        }
        .frame(minHeight: 56)
        .padding(.horizontal)
        .background(Color.customGreen)
    }
    
    var textfieldView: some View {
        TextField("Enter text", text: $text)
            .background(Color.white)
            .cornerRadius(10)
            .shadow(color: Color.gray, radius: 3, x: 0, y: 2)
            .frame(maxHeight: 24)
    }
}

#Preview {
    SearchBarView()
}
