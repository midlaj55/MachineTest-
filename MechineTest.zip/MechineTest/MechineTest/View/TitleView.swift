//
//  TitleView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI

struct TitleView: View {
    @EnvironmentObject var viewModel: ProductViewModel
    var itemType: ListType?

    var body: some View {
        HStack {
            if let section = viewModel.contentSectionModel.first(where: { $0.type == "categories" }) {
                let title = section.title
                if itemType == .catagories {
                    Text(title ?? "")
                }
            }
            if itemType == .bestProduct {
                Text("Most Popular")
                    .font(Font.system(size: 12))
            } else if itemType == .catagories {
                Text("Catagories")
                    .font(Font.system(size: 12))
            } else if itemType == .productsMostPopuplar {
                Text("Featured Products")
                    .font(Font.system(size: 12))
            }
            Spacer()
            Button(action: {}, label: {
                Text("View all")
                    .font(Font.system(size: 8))
                    .foregroundColor(.black)
            })
        }
        .padding(.horizontal)
        .padding(.vertical, 5)
    }
}
