//
//  ContentView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI

struct BseView: View {
    @StateObject var viewModel = ProductViewModel()

    var body: some View {
        VStack(spacing: 0) {
            SearchBarView()
            ScrollView(showsIndicators: false) {
                    SliderView()
                VStack {
                    TitleView(itemType: .bestProduct)
                    ItemListView(itemType: .productsMostPopuplar)
                    CardView()
                    TitleView(itemType: .catagories)
                    CatagoriesListView()
                    TitleView(itemType: .productsMostPopuplar)
                    ItemListView(itemType: .bestProduct)
                    
                }
                .padding(EdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8))
            }
        }
        .environmentObject(viewModel)
        .onAppear {
            if viewModel.contentSectionModel.isEmpty {
                viewModel.getItemListValues()
            }
        }
    }
}

struct BseView_Previews: PreviewProvider {
    static var previews: some View {
        BseView()
    }
}
