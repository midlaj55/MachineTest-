//
//  TabBarView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//


import SwiftUI

struct TabBarView: View {
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            BseView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(0)
            
            Text("Tab 2")
                .tabItem {
                    Image(systemName: "2.circle")
                    Text("Category")
                }
                .tag(1)
            
            Text("Tab 3")
                .tabItem {
                    Image(systemName: "cart")
                    Text("Cart")
                }
                .tag(2)
            
            Text("Tab 4")
                .tabItem {
                    Image(systemName: "4.circle")
                    Text("Offers")
                }
                .tag(3)
            
            Text("Tab 5")
                .tabItem {
                    Image(systemName: "person")
                    Text("Acount")
                }
                .tag(4)
        }
        .accentColor(.blue)
        .background(Color.white)
    }
}

#Preview {
    TabBarView()
}
