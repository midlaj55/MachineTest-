//
//  IteamListView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI
import Kingfisher

struct ItemListView: View {
    @EnvironmentObject var viewModel: ProductViewModel
    var itemType: ListType?
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(spacing: 8, content: {
                if itemType == .productsMostPopuplar {
                    ForEach(viewModel.mostPopularProductIteam, id: \.self) { index in
                        ItemView(data: index, itemType: .productsMostPopuplar)
                    }
                } else if itemType == .bestProduct {
                    ForEach(viewModel.bestProductIteam, id: \.self) { index in
                        ItemView(data: index, itemType: .bestProduct)
                    }
                }
            })
        }
    }
}

struct ItemView: View {
    @State var data: ContentItem?
    var itemType: ListType?

    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                if itemType == .productsMostPopuplar || itemType == .bestProduct {
                    Spacer()
                    KFImage(URL(string: data?.productImage ?? ""))
                        .resizable()
                        .scaledToFit()
                        .clipped()
                    Spacer()
                }
//                if let discountString = data?.discount, let discount = Double(discountString), discount > 0 {
                Text(data?.discount ?? "")
                    .font(Font.system(size: 5))
                    .padding(5)
                    .background(Color.orange)
                    .cornerRadius(5)
//                }
                Text(data?.productName ?? "")
                    .font(Font.system(size: 5))
                    .lineLimit(2)
                RatingView(rating: data?.productRating ?? 0)
                HStack {
                    Text(data?.offerPrice ?? "")
                    Text(data?.actualPrice ?? "")
                        .strikethrough()
                }
                .font(Font.system(size: 5))
            }.padding(5)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray, lineWidth: 1)
        )
        .frame(width: 96, height: 152)
    }
}

struct RatingView: View {
    let rating: Int

    var body: some View {
        HStack(spacing: 2) {
            ForEach(0..<5) { index in
                Image(systemName: index < rating ? "star.fill" : "star.fill")
                    .resizable()
                    .foregroundColor(index < rating ? .yellow : .secondary)
                    .frame(width: 6, height: 6)
            }
        }
    }
}
