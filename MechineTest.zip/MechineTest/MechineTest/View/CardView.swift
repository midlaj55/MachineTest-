//
//  CardView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI
import Kingfisher

struct CardView: View {
    @EnvironmentObject var viewModel: ProductViewModel

    var body: some View {
        VStack {
            KFImage(URL(string: viewModel.singleBannerIteam ?? ""))
                .resizable()
                .scaledToFill()
                .frame(maxHeight: 96)
                .cornerRadius(10)
        }
    }
}
