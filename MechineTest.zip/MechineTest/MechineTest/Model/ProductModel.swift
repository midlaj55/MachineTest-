//
//  ContentSectionModel.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import Foundation

public struct ProductModel: Codable {
    public let id: String?
    public let type: String?
    public let title: String?
    public let contents: [ContentItem]?
    public let image_url: String?
}

public struct ContentItem: Codable, Hashable {
    public let sku: String?
    public let productName: String?
    public let productImage: String?
    public let productRating: Int?
    public let actualPrice: String?
    public let offerPrice: String?
    public let discount: String?
    public let title: String?
    public let imageUrl: String?

    private enum CodingKeys: String, CodingKey {
        case sku
        case productName = "product_name"
        case productImage = "product_image"
        case productRating = "product_rating"
        case actualPrice = "actual_price"
        case offerPrice = "offer_price"
        case discount
        case title
        case imageUrl = "image_url"
    }
}
