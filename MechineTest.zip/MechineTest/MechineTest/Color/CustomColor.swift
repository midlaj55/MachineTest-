//
//  CustomColor.swift
//  MechineTest
//
//  Created by Mc on 12/03/24.
//

import Foundation
import SwiftUI

extension Color {
    static let customGreen = Color("headerViewColor")
}
