//
//  Service.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import Foundation
import Alamofire

protocol IteamListServiceDelegate: AnyObject {
    func productSuccessResponse(_ response: [ProductModel])
    func productFailResponse()
}

class IteamListService {
    weak var delegate: IteamListServiceDelegate?
}

extension IteamListService {
    // MARK: get All Movie Categories list data
    func getAllMoviewCategories() {
        let url = URL(string: "https://64bfc2a60d8e251fd111630f.mockapi.io/api/Todo")!
        AF.request(url, method: .get)
            .responseDecodable(of: [ProductModel].self) { response in
                switch response.result {
                case .success(let value):
                    // Handle successful decoding of JSON response
                    self.delegate?.productSuccessResponse(value)
                case .failure(let error):
                    // Handle failure
                    self.delegate?.productFailResponse()
                    print("error\(error)")
                }
            }
    }
}
