//
//  MechineTestApp.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI

@main
struct MechineTestApp: App {

    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)
        }
    }
}
