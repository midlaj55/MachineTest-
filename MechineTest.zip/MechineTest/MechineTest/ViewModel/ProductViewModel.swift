//
//  ProductViewModel.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import Foundation

public enum ListType: String {
    case banner_single
    case productsMostPopuplar
    case bestProduct
    case banner_slider
    case catagories
}

class ProductViewModel: ObservableObject {
    @Published var contentSectionModel: [ProductModel] = []
    @Published var bestProductIteam: [ContentItem] = []
    @Published var mostPopularProductIteam: [ContentItem] = []
    @Published var categoriIteam: [ContentItem] = []
    @Published var sliderIteam: [ContentItem] = []
    @Published var singleBannerIteam: String?
    fileprivate var service = IteamListService()
    init() {
        service.delegate = self
    }

    func getItemListValues() {
        service.getAllMoviewCategories()
    }

    func processAPIResponse(_ response: [ProductModel]) {
        for item in response {
            switch item.type {
            case "catagories":
                if let categoryContents = item.contents as? [ContentItem] {
                    // Handle category contents
                    for category in categoryContents {
                        self.categoriIteam.append(category)
                    }
                }
            case "products":
                if let productContents = item.contents as? [ContentItem] {
                    for product in productContents {
                        if item.title == "Best Sellers" {
                            self.bestProductIteam.append(product)
                        } else if item.title == "Most Popular" {
                            self.mostPopularProductIteam.append(product)
                        }
                    }
                }
            case "banner_slider":
                if let bannerContents = item.contents as? [ContentItem] {
                    for banner in bannerContents {
                        self.sliderIteam.append(banner)
                    }
                }
            case "banner_single":
                if let singleBannerContents = item.image_url {
                    self.singleBannerIteam = singleBannerContents
                }
            default:
                break
            }
        }
    }
}

extension ProductViewModel: IteamListServiceDelegate {
    func productSuccessResponse(_ response: [ProductModel]) {
        self.contentSectionModel = response
        processAPIResponse(response)
    }

    func productFailResponse() {
        
    }
}
