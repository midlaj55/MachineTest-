//
//  ResponseEntity+CoreDataClass.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//
//

//import Foundation
//import CoreData
//
//@objc(ResponseEntity)
//public class ResponseEntity: NSManagedObject {
//
//}
